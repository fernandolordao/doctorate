# Os dados

Usamos a imagem `travistorrent_8_2_2017.csv` de [https://travistorrent.testroots.org]. Como são 3GB, os dados ficam fora desse repo. 
